namespace FawryInternship.Models
{
    public interface IShippable
    {
        string GetName();
        double GetWeight();
    }
}
